using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flightcontrolls : MonoBehaviour
{
    private float speed = 20;
    private float turnSpeed = 45;
    private float horizontalInput;
    private float forwardInput;
    void Update()
    {
        if (!PlayerController.isCarEnabled)
        {
            // Move the vehicle forward
            horizontalInput = Input.GetAxis("Horizontal");
            forwardInput = Input.GetAxis("Vertical");
            //moves car forward
            transform.Translate(Vector3.forward * Time.deltaTime * speed * forwardInput);
            //rotates car
            transform.Rotate(Vector3.up, turnSpeed * horizontalInput * Time.deltaTime);
        }
    }
}
