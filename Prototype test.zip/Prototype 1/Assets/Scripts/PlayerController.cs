using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float speed = 20;
    private float turnSpeed = 45;
    private float horizontalInput;
    private float forwardInput;

    [SerializeField] private Transform plane;
    [SerializeField] private Transform camera;
    [SerializeField] private Transform cameraPosPlane;
    [SerializeField] private Transform cameraPosCar;

    [SerializeField] private bool carEnabled = true;

    public static bool isCarEnabled;
    void Update()
    {
        CheckCarEnabled();

        if (isCarEnabled)
        {
            // Move the vehicle forward
            horizontalInput = Input.GetAxis("Horizontal");
            forwardInput = Input.GetAxis("Vertical");
            //moves car forward
            transform.Translate(Vector3.forward * Time.deltaTime * speed * forwardInput);
            //rotates car
            transform.Rotate(Vector3.up, turnSpeed * horizontalInput * Time.deltaTime);
        }
    }

    private void CheckCarEnabled()
    {
        isCarEnabled = carEnabled;

        if (carEnabled)
        {
            camera.parent = transform;
            camera.position = cameraPosCar.position;
            camera.rotation = cameraPosCar.rotation;
        }
        else
        {
            camera.parent = plane;
            camera.position = cameraPosPlane.position;
            camera.rotation = cameraPosPlane.rotation;
        }
    }
}
